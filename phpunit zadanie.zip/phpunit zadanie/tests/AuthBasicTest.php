<?php

require('app/AuthBasic.php');


use PHPUnit\Framework\TestCase;


class AuthBasicTest extends TestCase {
	
    public function setUp() : void {
        $this->instance = new AuthBasic();
    }
    public function tearDown() : void {
        unset($this->instance);
    }


    public function testCreateCode(){
        $out = $this->instance->createCode();

       
        fwrite(STDERR, print_r($out, true));
        $len = strlen($out);
        $this->assertIsNumeric($out,'Wylosowano: '.$out);
        $this->assertEquals(6,$len,'Długość: '.$len);
    
        $out = $this->instance->createCode(4);
        $len = strlen($out);
        $this->assertIsNumeric($out,'Wylosowano: '.$out);
        $this->assertEquals(4,$len,'Długość: '.$len);

      
        $out = str_pad(1111,6,'0',STR_PAD_LEFT);
        $len = strlen($out);
        $this->assertIsNumeric($out,'Wylosowano: '.$out);
        $this->assertEquals(6,$len,'Długość: '.$len);

        $out = $this->instance->createCode(8);
        $out = strlen($out);
        $this->assertIsNumeric($out, 'Wylosowano: '.$out);
        $this->assertEquals(8,$len,'Długość: '.$len);
    }

    public function testCreateAuthToken(){
       
        $exp = array(
            'emlAuth'=>'gpetri@gplweb.pl','authCode'=>'131313',
            'authDate'=>date("Y-m-d"),'authHour'=>date("H:i:s"),
            'addrIp'=>'127.0.0.1','reqOs'=>'Linux','reqBrw'=>'FF'
        );

       
        $out = $this->instance->createAuthToken('gpetri@gplweb.pl',13);
        
      
        $out['authCode'] = '131313';
        
      
        $this->assertEquals($exp,$out,'Tablice są różne');

      
        $this->assertInstanceOf($exp::class, $out:class);
        $this->assertInstanceOf(String::class, $out["authCode"]);
       
        $this->assertTrue(strlen($out['authCode']) == 6, "Dlugosc hasha sie nie zgadza (mniejsza lub wieksza od 6 zamiast rowna 6)");
        

    public function testGenFingerprint(){
        // ??
        $this->assertEquals($exp,$out,'Tablice są różne');
    }

    public function verifyQuickRegCode() {
        $out = $this->instance->verifyQuickRegCode();
        $this->assertEquals(true, $out, "nie Zgadza sie")
    }
}




?>