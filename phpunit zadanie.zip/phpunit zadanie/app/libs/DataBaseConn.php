<?php

class DataBaseConn {
    String $host;
    String $user;
    String $pw;
    String $db;

  
    public function put(String $table, $columns, $values) {
        $mysqli = new mysqli($host, $user, $pw, $db);

        if ($mysqli -> connect_errno) {
            echo "FAILED CONNECTION";
            return
        }

        
        $query = "INSERT INTO ".$table." (".$columns.") VALUES (".$values.");";

        $allOk = false;

       
        if($mysqli->query($query) === TRUE) {
            echo "ADDED RECORD OK";
            $allOk = true;
        } else {
            echo "ERROR: ".$mysqli->error;
        }

       
        $mysqli->close();
        return $allOk;
    }
    public function get(String $table, $columns, $arrayOptions) {
        $mysqli = new mysqli($host, $user, $pw, $db);

        if ($mysqli -> connect_errno) {
            echo "FAILED CONNECTION";
            return
        }

       
        $query = "SELECT ".$columns." FROM ".$table." WHERE ".$arrayOptions.";";

        $result = $mysqli->query($query);

        $allOk = false;
        
        if($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                print_r($row);
            }
            $allOk = true;
        } else {
            echo "Brak wynikow";
        }

       
        $mysqli->close();
        return $allOk;
    }

   
    public function delete(String $table, String $conditions) {
        $mysqli = new mysqli($host, $user, $pw, $db);

        if ($mysqli -> connect_errno) {
            echo "FAILED CONNECTION";
            return
        }

       
        $query = "DELETE FROM ".$table." WHERE ".$conditions.";";

        $result = $mysqli->query($query);

        $allOk = false;
        
        if($result) {
            echo "Usunieto rekordy";
            $allOk = true;
           
        } else {
            echo "Brak wynikow";
            
        }
       
        $mysqli->close();
        return $allOk;
    }


}





?>