<?php

class DataBaseConn {
    String $host;
    String $user;
    String $pw;
    String $db;

    // czy columns to array pojedynczych stringow? czy to jeden string z kolumnami po przecinku???
    // to samo z values
    // zakladam ze jeden string z przecinkami 
    public function put(String $table, $columns, $values) {
        $mysqli = new mysqli($host, $user, $pw, $db);

        if ($mysqli -> connect_errno) {
            echo "FAILED CONNECTION";
            return
        }

        // sql injection go brrrrrrrrr
        $query = "INSERT INTO ".$table." (".$columns.") VALUES (".$values.");";

        $allOk = false;

        // oki doki or disaster
        if($mysqli->query($query) === TRUE) {
            echo "ADDED RECORD OK";
            $allOk = true;
        } else {
            echo "ERROR: ".$mysqli->error;
        }

        // connection terminated,,
        $mysqli->close();
        return $allOk;
    }
    public function get(String $table, $columns, $arrayOptions) {
        $mysqli = new mysqli($host, $user, $pw, $db);

        if ($mysqli -> connect_errno) {
            echo "FAILED CONNECTION";
            return
        }

        // sql injection go brrrrrrrrr
        $query = "SELECT ".$columns." FROM ".$table." WHERE ".$arrayOptions.";";

        $result = $mysqli->query($query);

        $allOk = false;
        // drukarka lub dust and echoes
        if($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                print_r($row);
            }
            $allOk = true;
        } else {
            echo "Brak wynikow";
        }

        // connection terminated,,
        $mysqli->close();
        return $allOk;
    }

    // funkcja nie byla w diagramie ale na koncu zadania malym druczkiem jest napisane zeby
    // ta klasa tez mogla usuwac
    public function delete(String $table, String $conditions) {
        $mysqli = new mysqli($host, $user, $pw, $db);

        if ($mysqli -> connect_errno) {
            echo "FAILED CONNECTION";
            return
        }

        // sql injection go brrrrrrrrr
        $query = "DELETE FROM ".$table." WHERE ".$conditions.";";

        $result = $mysqli->query($query);

        $allOk = false;
        // echo
        if($result) {
            echo "Usunieto rekordy";
            $allOk = true;
            // the clock stopped ticking forever ago
        } else {
            echo "Brak wynikow";
            // how long have i been up
        }
        // i dont know 

        // connection terminated,,
        $mysqli->close();
        return $allOk;
    }


}





?>