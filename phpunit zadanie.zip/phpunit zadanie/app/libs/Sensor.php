<?php

require 'vendor/autoload.php'

class Sensor {
    public function isLocal() {
        // "" 'sprawdzać' wszystkie lokalne adresy IPv4 oraz IPv6 "" ??????
        // starsze php: getHostByName(php_uname('n'));
        $localIP = getHostByName(getHostName());
        $serverIP = $_SERVER["SERVER_ADDR"];

        return $localIP;
    }
    public function addrIp($getProxy = null) {
        $remoteAddr = $_SERVER["REMOTE_ADDR"];
        $httpForwarder = $_SERVER["HTTP_X_FORWARDER_FOR"];
        // nie wiem co metoda ma zwracac ani co ma robic poza "uzywaniem" tych zmiennych powyzej
        return $remoteAddr;
    }
    public function browser() {
        $result = new WhichBrowser\Parser(getallheaders());
        $out = $result->browser->toString();
        
        return $out;
    }
    public function system() {
        $result = new WhichBrowser\Parser(getallheaders());
        $out = $result->os->toString();
        
        return $out;
    }
    public function genFingerprint($algo="sha512") {
        $UserAgent = $_SERVER['HTTP_USER_AGENT'];
        $hash = hash_hmac($algo, $UserAgent, hash($algo, $UserAgent), true);
        
        return $hash;
    } 
}







?>